<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'wordpress' );

/** Database password */
define( 'DB_PASSWORD', 'wordpress' );

/** Database hostname */
define( 'DB_HOST', 'mariadb' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'dHr9XENY D%ySeD_Z}ws*ZL?mA!uIU%bnA*zPx{~JRECU@Q:Wp0kF-T`R`!</Yqr' );
define( 'SECURE_AUTH_KEY',   '2!~5hPu46lK(ZEuvf4t[rClEC1S6S6g:*4:9!Q(Uob`<T/PcS/@RC_$(r^OfBc+b' );
define( 'LOGGED_IN_KEY',     'IC2bD5*]w5ms}ZUPS-:eWr0f3jmmm1F!3C&&2Qp@VC6Q}NK}S^ G*ShTgcSXe+d8' );
define( 'NONCE_KEY',         'afT,w;`{}{S>Yi)GPfe%b4B(j{eGi^hVc>$f38>y#7Z{%f2xucT&$ww~{s0NrY)9' );
define( 'AUTH_SALT',         'O,`C.suj,WHz/Jg1XP})!s|8[e*pRa_&9g5P>Kll<|[t8b,pkuziS=OgVScl >5G' );
define( 'SECURE_AUTH_SALT',  'wH+0_eyNG(Qsurz<[;6=LL^T8l5<^E:ujbGCW(ztbOV!&:te#d*,oLHITvb.X)28' );
define( 'LOGGED_IN_SALT',    ' 61Ode[Mw$4ikyjxlUnorQ[we*fzw?^*;bT.q*^^E78 QjYk}k@E}+-:X``yxKnc' );
define( 'NONCE_SALT',        'Z~*U(qRrlmU];l1dQ:dXV`#J}!&_/yf}cp@i?_O-0A!O&vOdy$(oI(b&Y1^=MLEW' );
define( 'WP_CACHE_KEY_SALT', 'q!W!<a]qN_6yQ1=[i,f[RY6p8C(A0@eTa@<qi9#q+qxo0R9:vTu*d@*#r#|:btDj' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
